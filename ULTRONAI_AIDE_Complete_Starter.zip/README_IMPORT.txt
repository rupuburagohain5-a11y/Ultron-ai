Copy app/src/main/* into your existing app/src/main/. Keep your existing Gradle files if AIDE already builds the project.
Package name should be com.mycompany.myapp.
The Gemini key must remain on your backend, not in the APK.
